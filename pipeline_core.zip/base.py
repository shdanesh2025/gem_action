# F:/very important audio transcribed using colab t4/process/help/colabs/gemini api/redesined/zip/WORKSPACE/pipeline_core/base.py
import json, re, os
from typing import Union

class Context:
    def __init__(self, item_id, group_id, workdir, responses_dir, step_config):
        self.item_id = item_id; self.group_id = group_id
        self.workdir = workdir; self.responses_dir = responses_dir
        self.step_config = step_config

    def read_response_json(self, step_id: int, suffix: str, custom_id: str = None) -> dict:
        target_id = custom_id if custom_id else self.item_id
        path = os.path.join(self.responses_dir, f"step_{step_id}", f"{target_id}{suffix}.json")
        if not os.path.exists(path): raise FileNotFoundError(f"Missing dependency: {path}")
        with open(path, "r", encoding="utf-8") as f: return json.load(f)
        
    def read_response_binary(self, step_id: int, filename_with_ext: str) -> bytes:
        path = os.path.join(self.responses_dir, f"step_{step_id}", f"{self.item_id}{filename_with_ext}")
        if not os.path.exists(path): raise FileNotFoundError(f"Missing binary: {path}")
        with open(path, "rb") as f: return f.read()

    def read_asset_json(self, filename: str) -> dict:
        path = os.path.join(self.workdir, "assets", filename)
        if not os.path.exists(path): raise FileNotFoundError(f"Missing asset: {path}")
        with open(path, "r", encoding="utf-8") as f: return json.load(f)

    def load_master_registry(self, folder: str, suffix: str) -> dict:
        cached_path = os.path.join(self.responses_dir, folder, f"{self.group_id}{suffix}")
        base_path = os.path.join(self.workdir, "assets", f"{self.group_id}{suffix}")
        path = cached_path if os.path.exists(cached_path) else (base_path if os.path.exists(base_path) else None)
        if path:
            with open(path, "r", encoding="utf-8") as f: return json.load(f)
        return {}

class BaseTransformer:
    def transform(self, previous_output: Union[str, bytes], context: Context) -> list:
        raise NotImplementedError()

class BaseValidator:
    def validate(self, response: Union[str, bytes], context: Context) -> Union[str, bytes]:
        raise NotImplementedError()

    def parse_json(self, text: str) -> dict:
        if isinstance(text, bytes): raise ValueError("Cannot parse binary data as JSON.")
        cleaned = text.strip()
        match = re.search(r"^```(?:[a-zA-Z0-9]+)?(?:\r?\n|\\n)(.*?)(?:\r?\n|\\n)```", cleaned, re.DOTALL | re.MULTILINE)
        if match: cleaned = match.group(1).strip()
        try: return json.loads(cleaned)
        except json.JSONDecodeError as e: raise ValueError(f"Invalid JSON syntax: {e}")

    def apply_declarative_validations(self, data: dict, context: Context):
        if "uuid_match" in context.step_config.get("declarative_validators", []):
            if data.get("id") != context.item_id:
                raise ValueError(f"UUID Mismatch! Expected: '{context.item_id}', got: '{data.get('id')}'.")

class BasePostProcessor:
    def parse_json(self, text: str) -> dict:
        if isinstance(text, bytes): raise ValueError("Cannot parse binary data as JSON.")
        cleaned = text.strip()
        match = re.search(r"^```(?:[a-zA-Z0-9]+)?(?:\r?\n|\\n)(.*?)(?:\r?\n|\\n)```", cleaned, re.DOTALL | re.MULTILINE)
        if match: cleaned = match.group(1).strip()
        return json.loads(cleaned)

    def post_process(self, response: Union[str, bytes], context: Context) -> dict:
        raise NotImplementedError()