# F:/very important audio transcribed using colab t4/process/help/colabs/gemini api/redesined/zip/WORKSPACE/pipeline_core/engine.py
import asyncio, time, random, os, sys, json, yaml, shutil, tempfile, re, traceback, importlib.util
from datetime import datetime
import pytz
from typing import Dict, List, Optional, Type, Any, Literal, Union
from google import genai
from google.genai import types
from tqdm.auto import tqdm
from pydantic import BaseModel, ValidationError, create_model, Field

from pipeline_core.base import Context

def get_class_name(file_path: str) -> str:
    """
    Safely parses a Python file to locate the defined class name.
    Handles trailing colons, whitespace, and inheritance definitions.
    """
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            stripped = line.strip()
            if stripped.startswith("class "):
                match = re.match(r"^class\s+(\w+)", stripped)
                if match:
                    return match.group(1)
    raise ValueError(f"No class definition found in {file_path}")

def clean_markdown_fences(text: str) -> str:
    cleaned = text.strip()
    match = re.search(r"^```(?:[a-zA-Z0-9]+)?(?:\r?\n|\\n)(.*?)(?:\r?\n|\\n)```", cleaned, re.DOTALL | re.MULTILINE)
    return match.group(1).strip() if match else cleaned

def validate_response_syntax(text: str, output_format: str, schema_class: Optional[Type[BaseModel]] = None) -> str:
    clean_text = clean_markdown_fences(text)
    fmt = output_format.lower()
    if fmt == 'json':
        try: parsed = json.loads(clean_text)
        except json.JSONDecodeError as e: raise ValueError(f"Invalid JSON syntax: {str(e)}")
    elif fmt == 'yaml':
        try: parsed = yaml.safe_load(clean_text)
        except Exception as e: raise ValueError(f"Invalid YAML syntax: {str(e)}")
    else: return clean_text

    if schema_class:
        try:
            if hasattr(schema_class, "model_validate"): schema_class.model_validate(parsed)
            else:
                from pydantic import TypeAdapter
                TypeAdapter(schema_class).validate_python(parsed)
        except ValidationError as e: raise ValueError(f"Schema mismatch: {str(e)}")
    return clean_text

def get_pacific_day_bucket() -> int:
    tz = pytz.timezone('US/Pacific')
    return datetime.now(tz).year * 10000 + datetime.now(tz).month * 100 + datetime.now(tz).day

def clean_schema_for_gemini(schema: Any, is_properties_parent: bool = False) -> Any:
    if isinstance(schema, dict):
        cleaned = {}
        for k, v in schema.items():
            if not is_properties_parent:
                if k in ["title", "$schema", "definitions", "$defs", "propertyOrdering"]: continue
            else:
                if k in ["propertyOrdering", "additionalProperties"]: continue
            actual_key = "anyOf" if k == "oneOf" else k
            cleaned[actual_key] = clean_schema_for_gemini(v, is_properties_parent=(k == "properties"))
        return cleaned
    elif isinstance(schema, list): 
        return [clean_schema_for_gemini(item, is_properties_parent) for item in schema]
    return schema

def package_book_group(group: List[str], group_id: str, local_responses_dir: str, gdrive_dir: str, pipeline_config: dict):
    steps = pipeline_config.get("steps", [])
    registries = pipeline_config.get("registries", [])
    with tempfile.TemporaryDirectory() as temp_dir:
        for step in steps:
            out_folder = step.get("output_folder")
            if out_folder: os.makedirs(os.path.join(temp_dir, out_folder), exist_ok=True)
        for reg in registries:
            reg_folder = reg.get("folder")
            if reg_folder: os.makedirs(os.path.join(temp_dir, reg_folder), exist_ok=True)
        os.makedirs(os.path.join(temp_dir, "middle_steps_backup"), exist_ok=True)
            
        for reg in registries:
            reg_folder, reg_suffix = reg.get("folder"), reg.get("suffix")
            if reg_folder and reg_suffix:
                src_reg = os.path.join(local_responses_dir, reg_folder, f"{group_id}{reg_suffix}")
                if os.path.exists(src_reg): shutil.copy2(src_reg, os.path.join(temp_dir, reg_folder, f"{group_id}{reg_suffix}"))
                
        for item_id in group:
            if "__" in item_id: continue
            for step in steps:
                out_folder = step.get("output_folder")
                if out_folder:
                    src_dir = os.path.join(local_responses_dir, out_folder)
                    if os.path.exists(src_dir):
                        for f in os.listdir(src_dir):
                            if f.startswith(item_id): shutil.copy2(os.path.join(src_dir, f), os.path.join(temp_dir, out_folder, f))
                            
            backup_dir = os.path.join(local_responses_dir, "middle_steps_backup")
            if os.path.exists(backup_dir):
                for f in os.listdir(backup_dir):
                    if f.startswith(item_id): shutil.copy2(os.path.join(backup_dir, f), os.path.join(temp_dir, "middle_steps_backup", f))
                        
        os.makedirs(gdrive_dir, exist_ok=True)
        zip_base_name = group_id
        pipeline_name = pipeline_config.get("pipeline_name", "")
        if pipeline_name:
            prefix = pipeline_config.get("state_file_prefix", "")
            if prefix != "main_":
                clean_suffix = re.sub(r'[^a-zA-Z0-9_]', '_', pipeline_name.lower())
                zip_base_name = f"{group_id}_{clean_suffix}"
                
        zip_filename = os.path.join(gdrive_dir, zip_base_name)
        shutil.make_archive(zip_filename, 'zip', temp_dir)
        print(f"\n📦 [Archived] Successfully saved to Google Drive: '{zip_base_name}.zip'")

class TokenReservation:
    def __init__(self, timestamp: float, tokens: int, task_id: str):
        self.timestamp = timestamp; self.tokens = tokens; self.task_id = task_id; self.status = "pending"

class AsyncKeyPool:
    def __init__(self, keys: List[str], rpm: int, daily: int, tpm: int, window_seconds: float = 60.0):
        self.keys = keys; self.rpm = rpm; self.daily = daily; self.tpm = tpm; self.window_seconds = window_seconds
        self.disabled_keys = set(); self.daily_usage: Dict[str, int] = {k: 0 for k in keys}
        self.windows: Dict[str, List[TokenReservation]] = {k: [] for k in keys}
        self.cooldowns: Dict[str, float] = {}
        self.current_day_bucket = get_pacific_day_bucket()
        self.lock = asyncio.Lock()

    def disable_key(self, key: str):
        self.disabled_keys.add(key)

    def penalize_key(self, key: str, duration: float = 60.0):
        self.cooldowns[key] = time.time() + duration

    def _reset_daily_counters(self):
        now_day = get_pacific_day_bucket()
        if now_day != self.current_day_bucket:
            for k in self.keys: self.daily_usage[k] = 0
            self.current_day_bucket = now_day

    async def acquire_key(self, task_id: str, estimated_tokens: int) -> str:
        while True:
            async with self.lock:
                now = time.time()
                self._reset_daily_counters()
                
                available_keys = []
                min_cooldown_expiry = float('inf')
                
                for k in self.keys:
                    if k in self.disabled_keys:
                        continue
                    cooldown_expiry = self.cooldowns.get(k, 0)
                    if cooldown_expiry < now:
                        available_keys.append(k)
                    else:
                        if cooldown_expiry < min_cooldown_expiry:
                            min_cooldown_expiry = cooldown_expiry
                
                active_keys = sorted(available_keys, key=lambda k: self.daily_usage[k])
                
                if not active_keys and self.keys:
                    non_disabled_exists = any(k not in self.disabled_keys for k in self.keys)
                    if not non_disabled_exists:
                        raise RuntimeError("All configured API keys are permanently disabled.")
                    wait_duration = max(min_cooldown_expiry - now, 0.1)
                else:
                    min_wait_time = float('inf')
                    for key in active_keys:
                        if self.daily_usage[key] >= self.daily: continue
                        window = [r for r in self.windows[key] if (r.status == "pending" and now - r.timestamp < 300.0) or r.timestamp >= now - self.window_seconds]
                        self.windows[key] = window
                        if len(window) < self.rpm and sum(r.tokens for r in window) + estimated_tokens <= self.tpm:
                            self.windows[key].append(TokenReservation(now, estimated_tokens, task_id))
                            self.daily_usage[key] += 1
                            return key
                        if window:
                            wait_time = (window[0].timestamp + self.window_seconds) - now
                            if wait_time < min_wait_time: min_wait_time = wait_time
                    if min_wait_time == float('inf'): raise RuntimeError("All keys reached daily limits.")
                    wait_duration = min_wait_time
            await asyncio.sleep(max(wait_duration + 0.005, 0.01))

    async def update_tokens(self, key: str, task_id: str, actual_tokens: int):
        async with self.lock:
            for res in self.windows[key]:
                if res.task_id == task_id and res.status == "pending":
                    res.tokens = actual_tokens; res.status = "completed"; res.timestamp = time.time()
                    break

def resolve_thinking_config(model_name: str, level_of_thinking: Optional[str], step_thinking_config: Optional[dict] = None, globals_dict: dict = None) -> Optional[dict]:
    resolved_level = level_of_thinking
    resolved_budget = None
    
    if step_thinking_config:
        resolved_level = step_thinking_config.get("thinking_level", resolved_level)
        resolved_budget = step_thinking_config.get("thinking_budget", resolved_budget)
    elif globals_dict:
        if resolved_level is None:
            resolved_level = globals_dict.get("THINKING_LEVEL", None)
        resolved_budget = globals_dict.get("THINKING_BUDGET", None)

    if resolved_level is not None:
        resolved_level = str(resolved_level).strip().lower()

    # Determine if model supports thinking_level (Gemini 3+)
    is_gemini_3 = "gemini-3" in model_name.lower() or "gemini-4" in model_name.lower()

    t_config = {}
    if is_gemini_3:
        if resolved_level in ["minimal", "low", "medium", "high"]:
            t_config["thinking_level"] = resolved_level
        elif resolved_budget is not None:
            budget_val = int(resolved_budget)
            if budget_val == 0:
                t_config["thinking_level"] = "minimal"
            elif budget_val > 0 and budget_val <= 1000:
                t_config["thinking_level"] = "low"
            elif budget_val > 1000 and budget_val <= 8192:
                t_config["thinking_level"] = "medium"
            elif budget_val > 8192:
                t_config["thinking_level"] = "high"
    else:
        if resolved_level in ["minimal", "low", "medium", "high"]:
            if resolved_level == "minimal":
                t_config["thinking_budget"] = 1024
            elif resolved_level == "low":
                t_config["thinking_budget"] = 2048
            elif resolved_level == "medium":
                t_config["thinking_budget"] = 8192
            elif resolved_level == "high":
                t_config["thinking_budget"] = 32768 if "pro" in model_name.lower() else 24576
        elif resolved_budget is not None:
            t_config["thinking_budget"] = int(resolved_budget)

    return {k: v for k, v in t_config.items() if v is not None}


class Orchestrator:
    def __init__(self, notebook_globals: dict):
        self.cfg = notebook_globals
        self.local_workdir = self.cfg.get("LOCAL_WORKDIR")
        self.responses_dir = self.cfg.get("LOCAL_RESPONSES_DIR")
        self.api_keys = self.cfg.get("API_KEYS", [])
        self.model = self.cfg.get("SELECTED_MODEL", "gemini-2.5-flash")
        self.max_retries = self.cfg.get("MAX_RETRIES", 3)
        self.gdrive_out = self.cfg.get("GDRIVE_OUTPUT_DIR")
        self.checkpoint_interval = self.cfg.get("CHECKPOINT_INTERVAL", 10)
        self.concurrent_size = self.cfg.get("CONCURRENT_REQUEST_SIZE", 5)
        self.max_response_tokens = self.cfg.get("MAX_RESPONSE_TOKENS", 65000)
        self.periodic_interval = self.cfg.get("PERIODIC_CHECKPOINT_INTERVAL", 300)
        self.save_backup_files = self.cfg.get("GET_MIDDLE_STEPS_BACKUP", True)
        self.retry_failed_items = self.cfg.get("RETRY_FAILED_ITEMS", True)
        
        config_path = os.path.join(self.local_workdir, self.cfg.get("PIPELINE_CONFIG_FILENAME", "pipeline_config.json"))
        with open(config_path, "r", encoding="utf-8") as f: self.pipeline_config = json.load(f)
            
        prefix = self.pipeline_config.get("state_file_prefix", "main_")
        self.state_file = os.path.join(self.gdrive_out, f"{prefix}progress_state.json")
        self.zip_base_path = os.path.join(self.gdrive_out, f"{prefix}responses_checkpoint")
        
        self.stats = { "waiting_for_key": 0, "in_flight_api": 0, "completed": 0, "errors": 0, "total_actual_tokens": 0, "current_concurrency": 5 }
        self.state_lock = asyncio.Lock()
        self.checkpoint_lock = asyncio.Lock()
        
        self.pool = AsyncKeyPool(self.api_keys, self.cfg.get("KEY_RPM_LIMIT", 15), self.cfg.get("KEY_DAILY_LIMIT", 500), self.cfg.get("KEY_TPM_LIMIT", 1000000))
        self.clients = {}
        self.cache = {}

        # Spacing/rate limiting queue synchronization
        self.last_request_time = 0.0
        self.launch_lock = asyncio.Lock()

    def load_state(self):
        if os.path.exists(self.state_file):
            try:
                with open(self.state_file, "r") as f: return json.load(f)
            except Exception: pass
        return {"completed_ids": [], "failed_ids": [], "completed_steps": {}, "errors": {}}

    def save_state(self, state):
        try:
            with open(self.state_file + ".tmp", "w") as f: json.dump(state, f, indent=2)
            os.replace(self.state_file + ".tmp", self.state_file)
        except Exception: pass

    async def _compile_and_run(self, script_path, class_name, method_name, *args):
        mtime = int(os.path.getmtime(script_path))
        cache_key = (script_path, mtime)
        if cache_key in self.cache: 
            instance = self.cache[cache_key]
        else:
            module_name = f"dyn_{hash(script_path) & 0xffffffff}_{mtime}"
            spec = importlib.util.spec_from_file_location(module_name, script_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            instance = getattr(module, class_name)()
            self.cache[cache_key] = instance
        return getattr(instance, method_name)(*args)

    async def sync_previous_cache(self):
        zip_path = self.zip_base_path + ".zip"
        if os.path.exists(zip_path):
            os.makedirs(self.responses_dir, exist_ok=True)
            try: await asyncio.to_thread(shutil.unpack_archive, zip_path, self.responses_dir)
            except Exception: pass

    async def trigger_gdrive_checkpoint(self, state):
        async with self.checkpoint_lock:
            with tempfile.TemporaryDirectory() as temp_dir:
                async with self.state_lock:
                    for filename in os.listdir(self.responses_dir):
                        src = os.path.join(self.responses_dir, filename)
                        if os.path.isfile(src): shutil.copy2(src, temp_dir)
                        elif os.path.isdir(src): shutil.copytree(src, os.path.join(temp_dir, filename), dirs_exist_ok=True)
                try:
                    await asyncio.to_thread(shutil.make_archive, self.zip_base_path, 'zip', temp_dir)
                    async with self.state_lock: self.save_state(state)
                except Exception: pass

    async def call_gemini_raw(self, req_id: str, prompt: Any, model: str, sys_prompt: str, response_schema: Optional[dict], step_cfg: dict, thinking_config: Optional[dict]) -> Union[str, bytes]:
        max_transient_retries = 5
        for t_attempt in range(1, max_transient_retries + 1):
            self.stats["waiting_for_key"] += 1
            key = await self.pool.acquire_key(req_id, 1000 + self.max_response_tokens)
            self.stats["waiting_for_key"] -= 1
            
            # Spacing Throttle Lock - Applies random 3-7 second spacing [1.2.6]
            async with self.launch_lock:
                now = time.time()
                elapsed = now - self.last_request_time
                spacing_interval = random.uniform(3.0, 7.0)
                if elapsed < spacing_interval:
                    await asyncio.sleep(spacing_interval - elapsed)
                self.last_request_time = time.time()

            self.stats["in_flight_api"] += 1
            try:
                if key not in self.clients: self.clients[key] = genai.Client(api_key=key)
                config_args = {}
                if sys_prompt: config_args["system_instruction"] = sys_prompt
                
                output_format = step_cfg.get("output_format", "json").lower()
                if output_format == 'json' or response_schema:
                    config_args["response_mime_type"] = "application/json"
                    if response_schema: config_args["response_schema"] = response_schema
                elif output_format == 'binary':
                    if step_cfg.get("response_modalities"): config_args["response_modalities"] = step_cfg.get("response_modalities")
                    if step_cfg.get("response_mime_type"): config_args["response_mime_type"] = step_cfg.get("response_mime_type")
                    
                    if step_cfg.get("speech_config"):
                        s_cfg = step_cfg.get("speech_config")
                        v_cfg = s_cfg.get("voice_config", {})
                        p_cfg = v_cfg.get("prebuilt_voice_config", {})
                        config_args["speech_config"] = types.SpeechConfig(
                            voice_config=types.VoiceConfig(
                                prebuilt_voice_config=types.PrebuiltVoiceConfig(
                                    voice_name=p_cfg.get("voice_name", "Kore")
                                )
                            )
                        )
                    
                if thinking_config:
                    cleaned_t_config = {k: v for k, v in thinking_config.items() if v is not None}
                    if cleaned_t_config: config_args["thinking_config"] = types.ThinkingConfig(**cleaned_t_config)
                    
                config = types.GenerateContentConfig(**config_args) if config_args else None
                response = await self.clients[key].aio.models.generate_content(model=model, contents=prompt, config=config)
                
                req_tokens = response.usage_metadata.total_token_count if response.usage_metadata else 1000
                self.stats["total_actual_tokens"] += req_tokens
                await self.pool.update_tokens(key, req_id, req_tokens)
                
                if not response.candidates or not response.candidates[0].content or not response.candidates[0].content.parts:
                    raise ValueError("Empty candidate payload generated by model.")
                    
                part = response.candidates[0].content.parts[0]
                if hasattr(part, "text") and part.text: return part.text
                elif hasattr(part, "inline_data") and part.inline_data.data: return part.inline_data.data
                else: return response.text
                    
            except Exception as e:
                await self.pool.update_tokens(key, req_id, 1000)
                status_code = getattr(e, 'code', None) or getattr(e, 'status_code', None)
                err_msg = str(e)
                err_upper = err_msg.upper()
                
                masked_key = f"...{key[-4:]}" if len(key) >= 4 else "unknown"
                if status_code in [400, 403]: 
                    print(f"🚫 [{req_id}] Hard Error ({status_code}). Permanently disabling key '{masked_key}'.")
                    self.pool.disable_key(key)
                
                is_transient = (status_code in [429, 500, 502, 503, 504]) or ("429" in err_msg) or ("503" in err_msg) or ("RESOURCE_EXHAUSTED" in err_upper) or ("SERVICE_UNAVAILABLE" in err_upper)
                
                if is_transient:
                    penalty_seconds = 60.0 if (status_code == 429 or "429" in err_msg or "RESOURCE_EXHAUSTED" in err_upper) else 30.0
                    self.pool.penalize_key(key, penalty_seconds)
                    
                    if t_attempt < max_transient_retries:
                        backoff = 0.2 + random.uniform(0.1, 0.3)
                        print(f"🚦 [{req_id}] Transient Error ({status_code or '429'}). Penalizing key '{masked_key}' for {penalty_seconds}s. Switching keys in {backoff:.1f}s (Attempt {t_attempt}/{max_transient_retries})...")
                        await asyncio.sleep(backoff)
                        continue
                raise e
            finally:
                self.stats["in_flight_api"] -= 1

    async def call_gemini_with_correction_loop(
        self, req_id: str, original_prompt: Any, model: str,
        system_prompt: Optional[str], native_schema: Optional[dict], validation_schema: Optional[Type[BaseModel]],
        step_cfg: dict, validator_path: Optional[str], context: Context,
        thinking_config: Optional[dict]
    ) -> Union[str, bytes]:
        current_prompt = original_prompt
        last_error_msg = ""
        out_fmt = step_cfg.get("output_format", "json").lower()
        
        for attempt in range(1, self.max_retries + 1):
            raw_response = None
            try:
                raw_response = await self.call_gemini_raw(req_id, current_prompt, model, system_prompt, native_schema, step_cfg, thinking_config)
                if not raw_response: raise ValueError("API returned empty.")
                
                if out_fmt != "binary": cleaned_validated = validate_response_syntax(raw_response, out_fmt, validation_schema)
                else: cleaned_validated = raw_response
                
                if validator_path:
                    v_class = get_class_name(validator_path)
                    cleaned_validated = await self._compile_and_run(validator_path, v_class, "validate", cleaned_validated, context)
                return cleaned_validated
            except Exception as e:
                last_error_msg = str(e)
                status_code = getattr(e, 'code', None) or getattr(e, 'status_code', None)
                err_upper = last_error_msg.upper()
                
                is_transient = (status_code in [429, 500, 502, 503, 504]) or ("429" in last_error_msg) or ("503" in last_error_msg) or ("RESOURCE_EXHAUSTED" in err_upper) or ("SERVICE_UNAVAILABLE" in err_upper)
                
                if is_transient:
                    backoff = (5 * attempt) + random.uniform(1.0, 3.0)
                    print(f"🚦 [{req_id}] All keys rate limited or transient errors exhausted. Retrying entire step in {backoff:.1f}s...")
                else:
                    backoff = (2 ** attempt) + random.uniform(0.5, 1.5)
                    print(f"⚠️ [{req_id}] Validation Failed. Retrying in {backoff:.1f}s (Correction Attempt {attempt}/{self.max_retries})...")
                    if attempt == self.max_retries: 
                        print(f"❌ [{req_id}] Correction Attempts Exhausted. Traceback:")
                        import traceback; traceback.print_exc()

                if attempt < self.max_retries:
                    await asyncio.sleep(backoff)
                    if raw_response is not None and not is_transient:
                        prev_disp = "[Binary Media Payload]" if isinstance(raw_response, bytes) else raw_response
                        correction_text = f"Your previous response failed validation.\n\nERROR:\n{last_error_msg}\n\nINSTRUCTIONS:\nReturn ONLY valid {out_fmt.upper()} satisfying rules."
                        if isinstance(original_prompt, list):
                            current_prompt = [item for item in original_prompt if not isinstance(item, str)]
                            current_prompt.append(correction_text)
                        else: current_prompt = f"ORIGINAL TASK:\n{original_prompt}\n\nYOUR PREVIOUS RESPONSE:\n{prev_disp}\n\n{correction_text}"
        raise ValueError(f"Exhausted {self.max_retries} correction attempts. Final Error: {last_error_msg}.")

    async def process_item(self, item_id: str, group_id: str, state: dict) -> bool:
        try:
            async with self.state_lock: completed = state["completed_steps"].setdefault(item_id, [])
            current_input = ""
            for step in self.pipeline_config.get("steps", []):
                step_key = f"step_{step['step_id']}"
                if step_key in completed:
                    out_folder = step.get("output_folder")
                    main_out_suffix = step.get("main_output_suffix")
                    current_input = read_local_response_file(item_id, step["step_id"], out_folder, main_out_suffix)
                    continue
                
                bypass_pattern = step.get("bypass_if_id_contains")
                if bypass_pattern and bypass_pattern in item_id:
                    dummy_out = "{}" if step.get("output_format", "json").lower() == "json" else ""
                    os.makedirs(os.path.join(self.responses_dir, step["output_folder"]), exist_ok=True)
                    with open(os.path.join(self.responses_dir, step["output_folder"], f"{item_id}{step.get('main_output_suffix')}.json"), "w") as f:
                        f.write(dummy_out)
                    async with self.state_lock: state["completed_steps"][item_id].append(step_key)
                    continue
                
                context = Context(item_id, group_id, self.local_workdir, self.responses_dir, step)
                
                if "transformer_path" in step:
                    t_path = os.path.join(self.local_workdir, step["transformer_path"])
                    class_name = get_class_name(t_path)
                    current_input = await self._compile_and_run(t_path, class_name, "transform", current_input, context)

                sys_path = os.path.join(self.local_workdir, step.get("system_prompt_path", ""))
                sys_prompt = open(sys_path, encoding="utf-8").read() if os.path.exists(sys_path) else ""
                
                raw_schema_dict = None
                if "schema_path" in step:
                    schema_path = os.path.join(self.local_workdir, step["schema_path"])
                    if os.path.exists(schema_path):
                        with open(schema_path, "r", encoding="utf-8") as f: raw_schema_dict = json.load(f)
                native_schema = clean_schema_for_gemini(raw_schema_dict) if (step["output_format"] == "json" and raw_schema_dict) else None
                validation_schema = None 
                
                v_path = os.path.join(self.local_workdir, step.get("validator_path", ""))
                validator_path = v_path if os.path.exists(v_path) else None
                
                step_model = step.get("model", self.model)
                resolved_thinking = resolve_thinking_config(step_model, step.get("level_of_thinking"), step.get("thinking_config"), self.cfg)
                
                result = await self.call_gemini_with_correction_loop(
                    f"{item_id}_{step_key}", current_input, step_model, sys_prompt, native_schema, validation_schema, step, validator_path, context, resolved_thinking
                )

                if self.save_backup_files and step != self.pipeline_config.get("steps", [])[-1]:
                    backup_dir = os.path.join(self.responses_dir, "middle_steps_backup")
                    os.makedirs(backup_dir, exist_ok=True)
                    ext = step.get("output_format", "json").lower()
                    backup_path = os.path.join(backup_dir, f"{item_id}_step_{step['step_id']}_response.{ext}")
                    
                    mode = "wb" if isinstance(result, bytes) else "w"
                    encoding = None if isinstance(result, bytes) else "utf-8"
                    with open(backup_path, mode, encoding=encoding) as f: f.write(result)

                if "post_process_path" in step:
                    p_path = os.path.join(self.local_workdir, step["post_process_path"])
                    class_name = get_class_name(p_path)
                    files_to_write = await self._compile_and_run(p_path, class_name, "post_process", result, context)
                    
                    for suffix, content in files_to_write.items():
                        target = step.get("output_folder", "output")
                        if suffix.startswith("DIR:"):
                            parts = suffix.split(":", 2)
                            target, suffix = parts[1], parts[2]
                        ident = group_id if suffix.startswith("GROUP_") else item_id
                        suffix = suffix.replace("GROUP_", "")
                        os.makedirs(os.path.join(self.responses_dir, target), exist_ok=True)
                        
                        mode = "wb" if isinstance(content, bytes) else "w"
                        encoding = None if isinstance(content, bytes) else "utf-8"
                        with open(os.path.join(self.responses_dir, target, f"{ident}{suffix}"), mode, encoding=encoding) as f:
                            f.write(content)
                            
                async with self.state_lock: state["completed_steps"][item_id].append(step_key)
            async with self.state_lock: state["completed_ids"].append(item_id)
            self.stats["completed"] += 1
            if self.stats["completed"] % self.checkpoint_interval == 0: await self.trigger_gdrive_checkpoint(state)
            return True
        except Exception as e:
            async with self.state_lock:
                state["failed_ids"].append(item_id)
                state["errors"][item_id] = str(e)
            self.stats["errors"] += 1
            print(f"\n❌ [ID {item_id}] Failed: {e}")
            return False

    async def group_worker(self, group: List[str], state: dict):
        group_id = group[0]
        for item_id in group:
            if item_id in state["completed_ids"]: continue
            if item_id in state["failed_ids"]: break
            success = await self.process_item(item_id, group_id, state)
            if not success: break
        
        async with self.state_lock: current_completed = set(state["completed_ids"])
        if all(item in current_completed for item in group):
            await asyncio.to_thread(package_book_group, group, group_id, self.responses_dir, self.gdrive_out, self.pipeline_config)

    async def status_monitor(self, total: int, active_tasks: set, init_comp: int, init_fail: int):
        desc = self.pipeline_config.get("pipeline_name", "Running Pipeline")
        pbar = tqdm(total=total, initial=init_comp, desc=desc, unit="item")
        l_comp, l_fail = init_comp, init_fail
        while active_tasks or self.stats["in_flight_api"] > 0:
            await asyncio.sleep(1.0)
            c_comp, c_fail = init_comp + self.stats["completed"], init_fail + self.stats["errors"]
            if c_comp > l_comp: pbar.update(c_comp - l_comp); l_comp = c_comp
            if c_fail > l_fail: pbar.update(c_fail - l_fail); l_fail = c_fail
            pbar.set_postfix({"API": self.stats["in_flight_api"], "Q": self.stats["waiting_for_key"]})
        pbar.close()

    async def periodic_timer_checkpoint(self, state, active_tasks, groups):
        while active_tasks or len(state["completed_ids"]) + len(state["failed_ids"]) < sum(len(g) for g in groups):
            await asyncio.sleep(self.periodic_interval)
            if active_tasks:
                print(f"⏰ [Periodic Backup] {self.periodic_interval // 60}-minute timer reached. Archiving progress to GDrive...")
                await self.trigger_gdrive_checkpoint(state)

    async def run(self) -> dict:
        await self.sync_previous_cache()
        
        preps = self.pipeline_config.get("preprocessors", [])
        for prep in preps:
            prep_path = os.path.join(self.local_workdir, prep)
            if os.path.exists(prep_path):
                class_name = get_class_name(prep_path)
                await self._compile_and_run(prep_path, class_name, "run", self) # <--- OOP Hook passes orchestrator instance

        with open(os.path.join(self.local_workdir, "siblings.json"), "r") as f: groups_list = json.load(f)
        state = self.load_state()
        
        if self.retry_failed_items:
            state["failed_ids"], state["errors"] = [], {}
            self.save_state(state)
            
        current_phase, total_phases = self.cfg.get("CURRENT_PHASE", 1), self.cfg.get("TOTAL_PHASES", 1)
        start_idx = (len(groups_list) * (current_phase - 1)) // total_phases
        end_idx = (len(groups_list) * current_phase) // total_phases
        phase_groups = groups_list[start_idx:end_idx]
        
        remaining = [g for g in phase_groups if [i for i in g if i not in state["completed_ids"] and i not in state["failed_ids"]]]
        if not remaining: return state
        
        total_items = {i for g in phase_groups for i in g}
        active_tasks = set()
        monitor = asyncio.create_task(self.status_monitor(len(total_items), active_tasks, len(total_items.intersection(set(state["completed_ids"]))), len(total_items.intersection(set(state["failed_ids"])))))
        
        timer_task = asyncio.create_task(self.periodic_timer_checkpoint(state, active_tasks, phase_groups))
        
        launched = 0
        while launched < len(remaining) or active_tasks:
            limit = self.concurrent_size
            while len(active_tasks) < limit and launched < len(remaining):
                active_tasks.add(asyncio.create_task(self.group_worker(remaining[launched], state)))
                launched += 1
            if active_tasks:
                # Mutate the active_tasks set in-place instead of rebinding it [1.2.6]
                done, pending = await asyncio.wait(active_tasks, return_when=asyncio.FIRST_COMPLETED)
                active_tasks.clear()
                active_tasks.update(pending)
        
        timer_task.cancel()
        await monitor
        await self.trigger_gdrive_checkpoint(state)
        return state

def read_local_response_file(file_prefix: str, step_id: int, output_folder: Optional[str] = None, output_suffix: Optional[str] = None) -> str:
    target_dir = os.path.join("/content/local_responses", output_folder) if output_folder else "/content/local_responses"
    suffix = output_suffix if output_suffix else f"_step_{step_id}"
    for ext in ["json", "yaml", "txt"]:
        filepath = os.path.join(target_dir, f"{file_prefix}{suffix}.{ext}")
        if os.path.exists(filepath):
            with open(filepath, "r", encoding="utf-8") as f: return f.read().strip()
    raise FileNotFoundError(f"Missing cached file for '{file_prefix}', step {step_id}")