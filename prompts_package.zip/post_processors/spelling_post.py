# F:/very important audio transcribed using colab t4/process/help/colabs/gemini api/redesined/zip/WORKSPACE/project_2/post_processors/spelling_post.py
from pipeline_core.base import BasePostProcessor, Context
import json

class SpellingPostProcessor(BasePostProcessor):
    def post_process(self, response_text: str, context: Context) -> dict:
        inc = self.parse_json(response_text)
        master = context.load_master_registry("spelling_profiles", "_spelling_register.json")
        if not master:
            master = {"id": context.group_id, "character_names": [], "location_names": [], "foreign_loanwords": [], "standardized_spellings": {}}
                
        for key in ["character_names", "location_names", "foreign_loanwords"]:
            combined_set = set(master.get(key, []) + inc.get(key, []))
            master[key] = sorted(list(combined_set))
        
        std_spellings = master.get("standardized_spellings", {})
        for sug in inc.get("suggestions", []):
            orig, corr = sug.get("w", "").strip(), sug.get("corrected", "").strip()
            if orig and corr and orig != corr: std_spellings[orig.lower()] = corr
        master["standardized_spellings"] = std_spellings
        
        return {
            "_spelling_suggestions.json": response_text,
            "DIR:spelling_profiles:GROUP__spelling_register.json": json.dumps(master, indent=2)
        }