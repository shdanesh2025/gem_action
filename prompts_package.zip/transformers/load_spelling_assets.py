# F:/very important audio transcribed using colab t4/process/help/colabs/gemini api/redesined/zip/WORKSPACE/project_2/transformers/load_spelling_assets.py
from pipeline_core.base import BaseTransformer, Context
from google.genai import types
import json

class SpellingTransformer(BaseTransformer):
    def transform(self, previous_output: str, context: Context) -> list:
        word_array_data = context.read_asset_json(f"{context.item_id}_00_word_array.json")
        register_data = context.load_master_registry("spelling_profiles", "_spelling_register.json")
        
        if not register_data:
            register_data = {"id": context.group_id, "character_names": [], "location_names": [], "foreign_loanwords": [], "standardized_spellings": {}}
            
        return [
            types.Part.from_bytes(data=json.dumps(word_array_data, indent=2).encode("utf-8"), mime_type="application/json"),
            types.Part.from_bytes(data=json.dumps(register_data, indent=2).encode("utf-8"), mime_type="application/json"),
            ""
        ]