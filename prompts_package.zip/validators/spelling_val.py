# F:/very important audio transcribed using colab t4/process/help/colabs/gemini api/redesined/zip/WORKSPACE/project_2/validators/spelling_val.py

# F:/very important audio transcribed using colab t4/process/help/colabs/gemini api/redesined/zip/WORKSPACE/project_2/validators/spelling_val.py
from pipeline_core.base import BaseValidator, Context
import unicodedata
import re

class SpellingValidator(BaseValidator):
    def validate(self, response_text: str, context: Context) -> str:
        data = self.parse_json(response_text)
        self.apply_declarative_validations(data, context)
        
        input_data = context.read_asset_json(f"{context.item_id}_00_word_array.json")
        input_words_map = {w.get("i"): w for w in input_data.get("words", []) if "i" in w}
        
        valid_cats = {
            "PHONETIC_TRANSCRIPTION_ERROR", 
            "DIACRITIC_ACCENT_RESTORATION", 
            "CHARACTER_NAME_UNIFORMITY", 
            "LOCATION_NAME_UNIFORMITY", 
            "ORTHOGRAPHIC_SPELLING_ERROR"
        }
            
        def normalize_word(text: str) -> str:
            if not text:
                return ""
            # NFD splits accented characters into base letters + combining marks (e.g., 'ñ' -> 'n' + '~')
            nfd_form = unicodedata.normalize('NFD', text)
            # Remove combining diacritical marks (Unicode category 'Mn')
            without_accents = "".join([c for c in nfd_form if unicodedata.category(c) != 'Mn'])
            # Remove punctuation / non-alphanumeric characters, then lowercase
            return re.sub(r'[^a-zA-Z0-9]', '', without_accents).lower()

        for idx, sug in enumerate(data.get("suggestions", [])):
            sug_i, sug_w, sug_cat, sug_corr = sug.get("i"), sug.get("w"), sug.get("category"), sug.get("corrected")
            
            if None in (sug_i, sug_w, sug_cat, sug_corr): 
                raise ValueError(f"Suggestion {idx} missing required fields.")
            if sug_cat not in valid_cats: 
                raise ValueError(f"Invalid category: '{sug_cat}'.")
            if sug_i not in input_words_map: 
                raise ValueError(f"Index Mismatch! '{sug_i}' does not exist.")
                
            original_text = input_words_map[sug_i].get("w", "")
            
            # Normalize both words to compare base characters only
            norm_gen = normalize_word(sug_w)
            norm_orig = normalize_word(original_text)
            
            if norm_gen != norm_orig:
                # If comparison fails, raise an error showing the original untrimmed strings
                raise ValueError(f"Alignment Error at {sug_i}! Expected '{original_text}', got '{sug_w}'.")
                
        return response_text
